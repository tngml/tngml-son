const MissionTwo = () => {

    const validation = (e) => {
        e.preventDefault(); // 폼의 기본 제출 동작 방지
        const id = e.target.elements.id.value;
        const pw = e.target.elements.pw.value;

        if (!id) {
            alert("please input data to ID.");
            return;
        }

        if (id.length < 3 || id.length > 15) {
            alert("ID는 3자리 이상 15자리 이하만 가능합니다.");
            return;
        }

        if (pw.length < 3 || pw.length > 15) {
            alert("PW는 3자리 이상 15자리 이하만 가능합니다.");
            return;
        }

        alert("로그인 성공");
    }

    return (
        <>
            <form onSubmit={validation}>
                <table border='1'>
                    <tr>
                        <th>ID</th>
                        <td><input type="text" name="id" /></td>
                    </tr>
                    <tr>
                        <th>PW</th>
                        <td><input type="password" name="pw" /></td>
                    </tr>
                    <tr>
                        <th colSpan='2'>
                            <input type="submit" value="Login" />
                        </th>
                    </tr>
                </table>
            </form>
        </>
    );
}

export default MissionTwo;
