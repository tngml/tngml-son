import { useState } from 'react';

const MissionThree = () => {
    const [boardList, setBoardList] = useState([
        {
            "num": 1,
            "title": "board-1",
            "createDt": "2024-09-30",
            "hit": 1
        },
        {
            "num": 2,
            "title": "board-2",
            "createDt": "2024-09-30",
            "hit": 10
        }
    ]);

    const [formData, setFormData] = useState({
        num: '',
        title: '',
        createDt: '',
        hit: 0 // 고정값
    });

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    }

    const addBoard = (e) => {
        e.preventDefault();
        if (formData.num === '' || formData.title === '' || formData.createDt === '') {
            alert("모든 필드를 입력하세요.");
            return;
        }

        const newBoard = {
            ...formData,
            hit: 0 // 고정된 hit 값
        };

        setBoardList([...boardList, newBoard]);


        setFormData({
            num: '',
            title: '',
            createDt: '',
            hit: 0,
        });
    }

    const list = () => {
        return (boardList.map((list) => {
            return (
                <tr key={list.num}>
                    <td>{list.num}</td>
                    <td>{list.title}</td>
                    <td>{list.createDt}</td>
                    <td>{list.hit}</td>
                </tr>
            );
        }));
    };

    const tableForm = () => {
        return (
            <>
                <h2>Add New Board</h2>
                <table border='1'>
                    <tbody>
                        <tr>
                            <th>Num</th>
                            <td><input type="number" name="num" value={formData.num} onChange={handleChange} /></td>
                        </tr>
                        <tr>
                            <th>Title</th>
                            <td><input type="text" name="title" value={formData.title} onChange={handleChange} /></td>
                        </tr>
                        <tr>
                            <th>CreateDt</th>
                            <td><input type="date" name="createDt" value={formData.createDt} onChange={handleChange} /></td>
                        </tr>
                        <tr>
                            <th>Hit</th>
                            <td><input type="num" name="hit" readOnly value={formData.hit} onChange={handleChange} /></td>
                        </tr>
                        <tr>
                            <th colSpan='2'>
                                <button onClick={addBoard}>ADD</button>
                            </th>
                        </tr>
                    </tbody>
                </table>
            </>
        );
    }

    return (
        <>
            <h1>Board List</h1>
            <hr />
            <table border="1">
                <thead>
                    <tr>
                        <th>Num</th>
                        <th>Title</th>
                        <th>CreateDt</th>
                        <th>Hit</th>
                    </tr>
                </thead>
                <tbody>
                    {list()}
                </tbody>
            </table>

            {tableForm()} {/* 새로운 폼을 화면에 렌더링 */}
        </>
    );
}

export default MissionThree;
