import './App.css';
import './News.css';
import NewsComponent from "../src/page/NewsComponent";

function App() {
  return (
    <NewsComponent />
    
  
  );

  
}

export default App;
